const AWS = require('aws-sdk');



AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
});


const createCodeCommitRepo = async (repositoryName) => {
  const codecommit = new AWS.CodeCommit();

  try {
    const result = await codecommit.createRepository({
      repositoryName,
    }).promise();

    console.log(`CodeCommit repository "${repositoryName}" created successfully`);
    return result.repositoryMetadata.repositoryName;
  } catch (error) {
    console.error('Error creating CodeCommit repository:', error);
    throw error;
  }
};

module.exports = createCodeCommitRepo;





