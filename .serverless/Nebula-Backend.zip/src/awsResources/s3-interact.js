const AWS = require("aws-sdk");
const express = require('express');

const createS3andStore = express.Router();

createS3andStore.post( '/s3/create/store', async (req,res) => {
  const { accessKeyId, secretAccessKey, bucketName, bucketPath } = req.body;
  try {
    // Set your AWS credentials
    const credentials = {
      accessKeyId: accessKeyId,
      secretAccessKey: secretAccessKey,
      region: process.env.AWS_REGION, // Replace with your desired region
    };

    // Create an S3 instance
    const s3 = new AWS.S3(credentials);

    // Create a bucket if it doesn't exist
    const bucketParams = {
      Bucket: projectName, // Replace with your desired bucket name
    };

    s3.headBucket(bucketParams, (err, data) => {
      if (err) {
        if (err.code === "NotFound") {
          s3.createBucket(bucketParams, (err, data) => {
            if (err) {
              console.log("Error:", err);
              reject(err);
            } else {
              console.log("Bucket Created:", data.Location);
              storeTerraformCode(bucketParams.Bucket,body,res);
              resolve();
            }
          });
        } else {
          console.log("Error:", err);
        }
      } else {
        console.log("Bucket already exists");
        storeTerraformCode(bucketParams.Bucket, body,res);
        resolve();
      }
    });
  } catch (error) {
    console.error("Error:", error);
  }
});

//Store Terraform code in S3
function storeTerraformCode(name, body,res) {
  const putParams = {
    Bucket: name, // S3 bucket name
    Key: `/${projectName}/temp/main.tf`, // Store our code in a temp folder
    Body: body, // Store result from AI/ML model
  };

  s3.putObject(putParams, (err, data) => {
    if (err) {
      console.log("Error:", err);
      res.status(400).json({ message: "Error storing Terraform code"});
    } else {
      console.log("Item Put:", data);
    }
  });
}

module.exports = createS3andStore;
