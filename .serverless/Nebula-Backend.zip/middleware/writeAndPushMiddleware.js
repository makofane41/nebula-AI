const fs = require('fs');
const { execSync } = require('child_process');

const writeToTerraformFile = (data) => {
    const filePath = 'main.tf';

    try {
        fs.writeFileSync(filePath, data);
        console.log(`Data written to ${filePath}`);
    } catch (error) {
        console.error(`Error writing to ${filePath}: ${error.message}`);
        throw error;
    }
};

const pushToCodeCommit = (codeCommitRepoUrl) => {
    try {
        execSync(`git add main.tf && git commit -m "Updated main.tf" && git push ${codeCommitRepoUrl} master`);
        console.log('Changes pushed to CodeCommit');
    } catch (error) {
        console.error(`Error pushing changes to CodeCommit: ${error.message}`);
        throw error;
    }
};

const writeAndPushMiddleware = (codeCommitRepoUrl) => async (req, res, next) => {
    const responseData = res.locals.completion;

    writeToTerraformFile(responseData);
    pushToCodeCommit(codeCommitRepoUrl);

    next();
};

module.exports = writeAndPushMiddleware;
