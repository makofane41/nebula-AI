module.exports = {
    JWT_SECRET: "Nebula-disraptor-key-for-JWT"
  };